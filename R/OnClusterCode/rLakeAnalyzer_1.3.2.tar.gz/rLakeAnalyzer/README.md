rLakeAnalyzer
===============

An R version of Lake Analyzer

Contributors: Jennie Brentrup, Luke Winslow, Richard Woolway, Jordan Read, Jake Zwart